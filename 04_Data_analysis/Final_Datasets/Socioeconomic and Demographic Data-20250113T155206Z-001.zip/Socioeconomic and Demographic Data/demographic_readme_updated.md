# Data Dictionary on Socio-Economic Demographic Data

Below is the data dictionary for the dataset demographicsAlt.csv:

| **Column Name** | **Description**                              | **Data Type** | **Possible Values/Units** | **Source**     | **Remarks**                             |
|-----------------|----------------------------------------------|---------------|---------------------------|----------------|-----------------------------------------|
| **Region**      | Name of the region                           | String        | List of regions           | Survey Data    | May contain missing values              |
| **Year**        | Year of observation                          | Integer       | 1950–2024                 | Historical Data| No missing values                      |
| **Indicator**   | Name of the indicator (e.g., Life Expectancy)| String        | Life Expectancy, etc.     | WHO            |                                         |
| **Percentage**  | Value of the indicator (%)                   | Float         | 0–100                     | WHO            | Converted from mixed data types to numerical, invalid values replaced with NaN|
| **Age**         | Age range                                    | String        | 5+, 18–22                 | WHO            | Range of Ages in the indicator          |
| **Gender**      | Gender                                       | String        | Male, Female              | WHO            | Gender, if specified in the indicator   |
| **Quintile**    | Quintile                                     | Integer       | 1, 2, 3, 4, 5             | WHO            | Standardized from descriptive and numeric values; missing values imputed with the mode |
