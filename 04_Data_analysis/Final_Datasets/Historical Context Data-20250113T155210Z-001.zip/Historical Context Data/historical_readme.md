The merged dataset for this segment includes the following information:

1.) Year

2.) Location of Violent Incident

3.) Number of Fatalities

4.) GDP Inflator Value at the Time of Incident
